import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-list',
  standalone: true,
  imports: [],
  templateUrl: './schedule-list.component.html',
  styleUrl: './schedule-list.component.scss'
})
export class ScheduleListComponent implements OnInit{
  schedules = [
    {
      schedule_id: 1,
      doctor_id: 101,
      schedule_date: new Date('2024-06-15'),
      schedule_time: '09:00 AM'
    },
    {
      schedule_id: 2,
      doctor_id: 102,
      schedule_date: new Date('2024-06-15'),
      schedule_time: '10:00 AM'
    }
    // Add more schedule objects as needed
  ];
  constructor() { }

  ngOnInit(): void {
  }
}
