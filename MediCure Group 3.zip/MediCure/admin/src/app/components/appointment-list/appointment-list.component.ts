import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-list',
  templateUrl: './appointment-list.component.html',
  styleUrls: ['./appointment-list.component.scss']
})
export class AppointmentListComponent implements OnInit {
  appointments = [
    {
      pname: 'John Doe',
      phone: '1234567890',
      p_age: '30',
      a_date: new Date('2023-06-12'),
      a_time: '10:00 AM',
      problem: 'Headache',
      doc_id: 1,
      pat_id: 101,
      status: 'Scheduled',
      pre_reprt: 'N/A'
    },
    {
      pname: 'Jane Smith',
      phone: '0987654321',
      p_age: '25',
      a_date: new Date('2023-06-13'),
      a_time: '2:00 PM',
      problem: 'Fever',
      doc_id: 2,
      pat_id: 102,
      status: 'Completed',
      pre_reprt: 'Blood test results attached'
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }
}
