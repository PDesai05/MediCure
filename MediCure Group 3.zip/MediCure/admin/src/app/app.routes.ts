import { Routes } from '@angular/router';
import { AppointmentListComponent } from './components/appointment-list/appointment-list.component';
import { ScheduleListComponent } from './components/schedule-list/schedule-list.component';
import { HomeComponent } from './shared/home/home.component';

export const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'appointment', component: AppointmentListComponent },
    { path: 'schedule', component: ScheduleListComponent },

];
