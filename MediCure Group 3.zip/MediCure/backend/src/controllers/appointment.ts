import { Request, Response } from 'express';
import Appointment from '../models/Appointment';
export class AppointmentController {
// Example function to create a new appointment
public createAppointment = async (req: Request, res: Response) => {
  try {
    const appointment = new Appointment(req.body);
    await appointment.save();
    res.status(201).json(appointment);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Example function to get all appointments
public getAppointments = async (req: Request, res: Response) => {
  try {
    const appointments = await Appointment.find();
    res.status(200).json(appointments);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}
}
