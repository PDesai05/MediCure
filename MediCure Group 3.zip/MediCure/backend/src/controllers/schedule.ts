import { Request, Response } from 'express';
import Schedule from '../models/Schedule';
export class ScheduleController {

// Example function to create a new schedule
public createSchedule = async (req: Request, res: Response) => {
  try {
    const schedule = new Schedule(req.body);
    await schedule.save();
    res.status(201).json(schedule);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Example function to get all schedules
public getSchedules = async (req: Request, res: Response) => {
  try {
    const schedules = await Schedule.find();
    res.status(200).json(schedules);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}
}
