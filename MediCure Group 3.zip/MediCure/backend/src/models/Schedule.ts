import { Schema, model } from 'mongoose';

export interface ISchedule {
  schedule_id: number;
  doctor_id: number;
  schedule_date: Date;
  schedule_time: string;
}

const scheduleSchema = new Schema<ISchedule>({
  schedule_id: { type: Number, required: true },
  doctor_id: { type: Number, required: true },
  schedule_date: { type: Date, required: true },
  schedule_time: { type: String, required: true }
});

const Schedule = model<ISchedule>('Schedule', scheduleSchema);

export default Schedule;
