import { Schema, model } from 'mongoose';

export interface IAppointment {
  pname: string;
  phone: string;
  p_age: string;
  a_date: Date;
  a_time: string;
  problem: string;
  doc_id: number;
  pat_id: number;
  status: string;
  pre_reprt: string;
  tid: string;
}

const appointmentSchema = new Schema<IAppointment>({
  pname: { type: String, required: true, maxlength: 50 },
  phone: { type: String, required: true, maxlength: 12 },
  p_age: { type: String, required: true, maxlength: 10 },
  a_date: { type: Date, required: true },
  a_time: { type: String, required: true },
  problem: { type: String, required: true, maxlength: 300 },
  doc_id: { type: Number, required: true },
  pat_id: { type: Number, required: true },
  status: { type: String, required: true, maxlength: 20 },
  pre_reprt: { type: String, maxlength: 500 },
  tid: { type: String, required: true, maxlength: 100 }
});

const Appointment = model<IAppointment>('Appointment', appointmentSchema);

export default Appointment;
