import { Router } from 'express';
import { AppointmentController } from '../controllers/appointment';
const appointmentController: AppointmentController = new AppointmentController();
const router = Router();



router.post('/schedule', appointmentController.createAppointment);
router.get('/schedules', appointmentController.getAppointments);
export default router;