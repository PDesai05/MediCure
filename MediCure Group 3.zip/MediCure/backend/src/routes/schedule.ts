import { Router } from 'express';
import { ScheduleController } from '../controllers/schedule';
const scheduleController: ScheduleController = new ScheduleController();
const router = Router();

router.post('/schedule', scheduleController.createSchedule);
router.get('/schedules', scheduleController.getSchedules);
export default router;